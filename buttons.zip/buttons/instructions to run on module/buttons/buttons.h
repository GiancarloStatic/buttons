class buttons{
public:
int button_a=0;
int button_b=0;
int a,b;
int old_button_a,old_button_b;
int setPins(int a,int b);
int refresh();
};