#include <Arduino.h>
#include "buttons.h"

int buttons::setPins(int a,int b){
button_a=a;
button_b=b;
}

int buttons_start=millis();
int buttons::refresh(){
if(millis()-buttons_start>100){
buttons_start=millis();

pinMode(button_a,OUTPUT);
pinMode(button_a,INPUT);    
pinMode(button_b,OUTPUT); 
pinMode(button_b,INPUT); 

a=digitalRead(button_a);
b=digitalRead(button_b);

if(old_button_a!=a||old_button_b!=b){
old_button_b=b;
old_button_a=a;
Serial.print(a);
Serial.print(":");
Serial.print(b);
Serial.print('\0');
}

}
}
